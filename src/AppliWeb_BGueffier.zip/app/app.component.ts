import { Component } from '@angular/core';
  
@Component({
  selector: 'pokemon-app',
  templateUrl: `./app/app.component.html`,
})
export class AppComponent { }